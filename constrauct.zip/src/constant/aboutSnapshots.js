export const SnapshotData = [
    { value: '30+', label: 'Residential Buildings' },
    { value: '50+', label: 'Commercial Buildings' },
    { value: '900', label: 'Specific Trades' },
    { value: '256+', label: 'Scheduling Projects' },
  ];