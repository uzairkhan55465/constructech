export const AboutTabs = [
    {
      title: 'Our Mission',
      content: 'Our mission is to streamline the construction process and deliver accurate, timely, and cost-effective solutions that meet your needs and exceed your expectations.',
    },
    {
      title: 'Our Vision',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.',
    },
    {
      title: 'Our Value',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.',
    },
  ];